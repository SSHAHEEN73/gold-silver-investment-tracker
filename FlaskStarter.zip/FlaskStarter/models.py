from app import db
from datetime import datetime
from sqlalchemy import func


class Investment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date())
    metal_type = db.Column(db.String(10), nullable=False)  # 'gold' or 'silver'
    investment_amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), nullable=False)  # 'AED' or 'KWD'
    price_per_gram = db.Column(db.Float, nullable=False)
    quantity_grams = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, date=None, metal_type=None, investment_amount=None, currency=None, 
                 price_per_gram=None, quantity_grams=None):
        self.date = date
        self.metal_type = metal_type
        self.investment_amount = investment_amount
        self.currency = currency
        self.price_per_gram = price_per_gram
        self.quantity_grams = quantity_grams
    
    def __repr__(self):
        return f'<Investment {self.metal_type} {self.investment_amount} {self.currency}>'


class MetalPrice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    metal_type = db.Column(db.String(10), nullable=False)  # 'gold' or 'silver'
    price_aed = db.Column(db.Float, nullable=False)  # Price per gram in AED
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, metal_type=None, price_aed=None):
        self.metal_type = metal_type
        self.price_aed = price_aed
    
    def __repr__(self):
        return f'<MetalPrice {self.metal_type} {self.price_aed} AED/gram>'
    
    @property
    def price_kwd(self):
        """Convert AED price to KWD (1 KWD = 12 AED)"""
        return self.price_aed / 12


class ProfitScenario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    percentage_growth = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, name=None, percentage_growth=None):
        self.name = name
        self.percentage_growth = percentage_growth
    
    def __repr__(self):
        return f'<ProfitScenario {self.name} {self.percentage_growth}%>'
