from flask_wtf import FlaskForm
from wtforms import FloatField, SelectField, DateField, StringField, SubmitField
from wtforms.validators import DataRequired, NumberRange, Length
from datetime import date


class InvestmentForm(FlaskForm):
    date = DateField('Investment Date', default=date.today, validators=[DataRequired()])
    metal_type = SelectField('Metal Type', 
                           choices=[('gold', 'Gold'), ('silver', 'Silver')], 
                           validators=[DataRequired()])
    investment_amount = FloatField('Investment Amount', 
                                 validators=[DataRequired(), NumberRange(min=0.01)])
    currency = SelectField('Currency', 
                         choices=[('AED', 'AED'), ('KWD', 'KWD')], 
                         validators=[DataRequired()])
    price_per_gram = FloatField('Price per Gram', 
                              validators=[DataRequired(), NumberRange(min=0.01)])
    submit = SubmitField('Add Investment')


class PriceUpdateForm(FlaskForm):
    gold_price_aed = FloatField('Gold Price (AED per gram)', 
                              validators=[DataRequired(), NumberRange(min=0.01)])
    silver_price_aed = FloatField('Silver Price (AED per gram)', 
                                validators=[DataRequired(), NumberRange(min=0.01)])
    submit = SubmitField('Update Prices')


class ProfitCalculatorForm(FlaskForm):
    scenario_name = StringField('Scenario Name', 
                              validators=[DataRequired(), Length(min=1, max=100)])
    percentage_growth = FloatField('Expected Growth (%)', 
                                 validators=[DataRequired(), NumberRange(min=-100, max=1000)])
    submit = SubmitField('Calculate Profit')


class CustomPriceForm(FlaskForm):
    gold_future_price = FloatField('Future Gold Price (AED per gram)', 
                                 validators=[NumberRange(min=0.01)])
    silver_future_price = FloatField('Future Silver Price (AED per gram)', 
                                   validators=[NumberRange(min=0.01)])
    submit = SubmitField('Calculate with Custom Prices')
