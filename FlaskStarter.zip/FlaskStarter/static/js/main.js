// Main JavaScript for Gold & Silver Investment Tracker

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Currency conversion calculator
    const currencyInputs = document.querySelectorAll('input[name="currency"], select[name="currency"]');
    currencyInputs.forEach(function(input) {
        input.addEventListener('change', function() {
            updateCurrencyHints(this.value);
        });
    });

    // Real-time form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Number input formatting
    const numberInputs = document.querySelectorAll('input[type="number"]');
    numberInputs.forEach(function(input) {
        input.addEventListener('blur', function() {
            if (this.value && !isNaN(this.value)) {
                const value = parseFloat(this.value);
                if (this.step === '0.01') {
                    this.value = value.toFixed(2);
                } else if (this.step === '0.001') {
                    this.value = value.toFixed(3);
                }
            }
        });
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Loading state for buttons
    const submitButtons = document.querySelectorAll('button[type="submit"], input[type="submit"]');
    submitButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            if (this.form && this.form.checkValidity()) {
                showLoadingState(this);
            }
        });
    });

    // Auto-save form data to localStorage (except sensitive data)
    const formInputs = document.querySelectorAll('input:not([type="password"]), select, textarea');
    formInputs.forEach(function(input) {
        // Load saved data
        const savedValue = localStorage.getItem('form_' + input.name);
        if (savedValue && input.type !== 'hidden') {
            input.value = savedValue;
        }

        // Save data on change
        input.addEventListener('change', function() {
            if (this.name && this.type !== 'hidden') {
                localStorage.setItem('form_' + this.name, this.value);
            }
        });
    });

    // Clear saved form data on successful submission
    forms.forEach(function(form) {
        form.addEventListener('submit', function() {
            if (this.checkValidity()) {
                const inputs = this.querySelectorAll('input:not([type="password"]), select, textarea');
                inputs.forEach(function(input) {
                    if (input.name) {
                        localStorage.removeItem('form_' + input.name);
                    }
                });
            }
        });
    });

    // Initialize charts if Chart.js is available
    if (typeof Chart !== 'undefined') {
        Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
        Chart.defaults.font.size = 12;
    }
});

// Utility Functions

function updateCurrencyHints(selectedCurrency) {
    const hints = document.querySelectorAll('.currency-hint');
    hints.forEach(function(hint) {
        if (selectedCurrency === 'KWD') {
            hint.textContent = '1 KWD = 12 AED (automatic conversion applied)';
        } else {
            hint.textContent = 'Amount in AED';
        }
    });
}

function showLoadingState(button) {
    const originalText = button.textContent || button.value;
    const loadingText = 'Processing...';
    
    if (button.tagName === 'BUTTON') {
        button.innerHTML = '<span class="loading me-2"></span>' + loadingText;
    } else {
        button.value = loadingText;
    }
    
    button.disabled = true;
    
    // Restore original state after 3 seconds (fallback)
    setTimeout(function() {
        if (button.tagName === 'BUTTON') {
            button.textContent = originalText;
        } else {
            button.value = originalText;
        }
        button.disabled = false;
    }, 3000);
}

function formatCurrency(amount, currency = 'AED') {
    return new Intl.NumberFormat('en-AE', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

function formatNumber(number, decimals = 2) {
    return new Intl.NumberFormat('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    }).format(number);
}

function convertKwdToAed(kwdAmount) {
    return kwdAmount * 12;
}

function convertAedToKwd(aedAmount) {
    return aedAmount / 12;
}

function calculateProfit(investment, currentValue) {
    const profit = currentValue - investment;
    const percentage = investment > 0 ? (profit / investment) * 100 : 0;
    return {
        amount: profit,
        percentage: percentage
    };
}

function animateNumber(element, targetValue, duration = 1000) {
    const startValue = parseFloat(element.textContent) || 0;
    const increment = (targetValue - startValue) / (duration / 16);
    let currentValue = startValue;
    
    const timer = setInterval(function() {
        currentValue += increment;
        if ((increment > 0 && currentValue >= targetValue) || 
            (increment < 0 && currentValue <= targetValue)) {
            currentValue = targetValue;
            clearInterval(timer);
        }
        element.textContent = formatNumber(currentValue);
    }, 16);
}

// Export functions for global use
window.InvestmentTracker = {
    formatCurrency: formatCurrency,
    formatNumber: formatNumber,
    convertKwdToAed: convertKwdToAed,
    convertAedToKwd: convertAedToKwd,
    calculateProfit: calculateProfit,
    animateNumber: animateNumber
};

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+S to save (prevent default and show save indication)
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        const activeForm = document.querySelector('form');
        if (activeForm) {
            const submitButton = activeForm.querySelector('button[type="submit"], input[type="submit"]');
            if (submitButton) {
                submitButton.click();
            }
        }
    }
    
    // Escape to close modals or go back
    if (e.key === 'Escape') {
        const modals = document.querySelectorAll('.modal.show');
        if (modals.length === 0) {
            // If no modals, try to find a cancel/back button
            const backButton = document.querySelector('a[href*="index"], .btn-secondary');
            if (backButton && backButton.href) {
                window.location.href = backButton.href;
            }
        }
    }
});

// Performance monitoring
if ('performance' in window) {
    window.addEventListener('load', function() {
        setTimeout(function() {
            const perfData = performance.getEntriesByType('navigation')[0];
            console.log('Page load time:', Math.round(perfData.loadEventEnd - perfData.loadEventStart), 'ms');
        }, 0);
    });
}

// Error handling for failed requests
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    // You could send this to a logging service in production
});

// Service worker registration (for offline functionality in production)
if ('serviceWorker' in navigator && window.location.protocol === 'https:') {
    navigator.serviceWorker.register('/sw.js').catch(function(error) {
        console.log('ServiceWorker registration failed:', error);
    });
}
