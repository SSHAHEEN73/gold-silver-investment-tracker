# Gold & Silver Investment Tracker

## Overview

This is a Flask-based web application for tracking gold and silver investments. The application allows users to record their precious metal investments, track current market prices, calculate profit scenarios, and generate comprehensive reports. It's designed to help investors manage their precious metal portfolios with features for investment tracking, price monitoring, and profit analysis.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Traditional server-side rendered HTML templates using Jinja2
- **Styling**: Bootstrap 5.3.0 for responsive UI components
- **Icons**: Font Awesome 6.0.0 for consistent iconography
- **JavaScript**: Vanilla JavaScript with Bootstrap components for interactivity
- **Templates**: Organized template structure with base template inheritance

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Database ORM**: SQLAlchemy with Flask-SQLAlchemy extension
- **Forms**: Flask-WTF with WTForms for form handling and validation
- **Session Management**: Flask's built-in session handling with secret key
- **Proxy Support**: ProxyFix middleware for deployment behind reverse proxies

### Database Design
- **Database**: SQLite (default) with PostgreSQL support via DATABASE_URL environment variable
- **Connection Pooling**: Configured with pool recycling and pre-ping for reliability
- **Models**: Three main entities:
  - `Investment`: Records individual investment transactions
  - `MetalPrice`: Stores current market prices for gold and silver
  - `ProfitScenario`: Saves profit calculation scenarios

## Key Components

### Data Models
1. **Investment Model**
   - Tracks investment date, metal type, amount, currency, price per gram
   - Automatically calculates quantity in grams
   - Supports both AED and KWD currencies

2. **MetalPrice Model**
   - Stores current gold and silver prices in AED per gram
   - Includes automatic KWD conversion (1 KWD = 12 AED)
   - Tracks last update timestamp

3. **ProfitScenario Model**
   - Saves named profit calculation scenarios
   - Stores percentage growth expectations

### Form Handling
- **InvestmentForm**: New investment entry with validation
- **PriceUpdateForm**: Current market price updates
- **ProfitCalculatorForm**: Percentage-based profit scenarios
- **CustomPriceForm**: Custom price-based profit calculations

### Utility Functions
- **PDF Report Generation**: Using ReportLab for comprehensive investment reports
- **Profit Calculations**: Supports both percentage growth and custom price scenarios
- **Currency Conversions**: Automatic AED/KWD conversions throughout the system

## Data Flow

1. **Investment Entry**: Users input investment details → Form validation → Database storage with calculated quantities
2. **Price Updates**: Admin updates current market prices → Database update → Dashboard reflects new values
3. **Profit Analysis**: Users select scenarios → System calculates profits based on current holdings → Results displayed with detailed breakdowns
4. **Reporting**: System aggregates all investment data → Generates PDF reports with charts and summaries

## External Dependencies

### Frontend Dependencies (CDN)
- Bootstrap 5.3.0: UI framework and responsive components
- Font Awesome 6.0.0: Icon library for visual consistency

### Python Dependencies
- Flask: Core web framework
- Flask-SQLAlchemy: Database ORM integration
- Flask-WTF: Form handling and CSRF protection
- WTForms: Form validation and rendering
- ReportLab: PDF generation for reports
- Werkzeug: WSGI utilities and middleware

### Optional Integrations
- PostgreSQL: Production database (configurable via DATABASE_URL)
- Reverse Proxy: Nginx/Apache support via ProxyFix middleware

## Deployment Strategy

### Environment Configuration
- **SESSION_SECRET**: Application secret key (defaults to development key)
- **DATABASE_URL**: Database connection string (defaults to SQLite)
- **Debug Mode**: Enabled for development, should be disabled in production

### Database Management
- Automatic table creation on first run
- Database migrations handled through SQLAlchemy
- Support for both SQLite (development) and PostgreSQL (production)

### Hosting Considerations
- Configured for deployment on platforms like Heroku, Railway, or traditional VPS
- ProxyFix middleware handles X-Forwarded headers correctly
- Static files served through Flask (consider CDN for production)
- Debug logging enabled (should be configured appropriately for production)

### Security Features
- CSRF protection through Flask-WTF
- Session management with configurable secret key
- Form validation and sanitization
- SQL injection prevention through SQLAlchemy ORM

The application follows a traditional MVC pattern with clear separation of concerns, making it maintainable and extensible for future enhancements like API endpoints, real-time price feeds, or advanced analytics features.