from flask import render_template, request, redirect, url_for, flash, make_response
from app import app, db
from models import Investment, MetalPrice, ProfitScenario
from forms import InvestmentForm, PriceUpdateForm, ProfitCalculatorForm, CustomPriceForm
from utils import generate_pdf_report, calculate_profit_scenarios, get_current_prices
import logging


@app.route('/')
def index():
    """Dashboard showing investment summary"""
    try:
        # Get total investments by metal type
        gold_investments = db.session.query(db.func.sum(Investment.investment_amount)).filter_by(metal_type='gold').scalar() or 0
        silver_investments = db.session.query(db.func.sum(Investment.investment_amount)).filter_by(metal_type='silver').scalar() or 0
        
        # Get total quantities
        gold_quantity = db.session.query(db.func.sum(Investment.quantity_grams)).filter_by(metal_type='gold').scalar() or 0
        silver_quantity = db.session.query(db.func.sum(Investment.quantity_grams)).filter_by(metal_type='silver').scalar() or 0
        
        # Get recent investments
        recent_investments = Investment.query.order_by(Investment.created_at.desc()).limit(5).all()
        
        # Get current prices
        current_prices = get_current_prices()
        
        return render_template('index.html', 
                             gold_investments=gold_investments,
                             silver_investments=silver_investments,
                             gold_quantity=gold_quantity,
                             silver_quantity=silver_quantity,
                             recent_investments=recent_investments,
                             current_prices=current_prices)
    except Exception as e:
        logging.error(f"Error in index route: {e}")
        flash('Error loading dashboard data', 'error')
        return render_template('index.html')


@app.route('/add_investment', methods=['GET', 'POST'])
def add_investment():
    """Add new investment entry"""
    form = InvestmentForm()
    
    if form.validate_on_submit():
        try:
            # Convert investment amount to AED if in KWD
            investment_amount = form.investment_amount.data or 0
            price_per_gram = form.price_per_gram.data or 0
            
            if form.currency.data == 'KWD':
                investment_amount_aed = investment_amount * 12
                price_per_gram_aed = price_per_gram * 12
            else:
                investment_amount_aed = investment_amount
                price_per_gram_aed = price_per_gram
            
            # Calculate quantity in grams
            if price_per_gram_aed > 0:
                quantity_grams = investment_amount_aed / price_per_gram_aed
            else:
                quantity_grams = 0
            
            # Create new investment
            investment = Investment(
                date=form.date.data,
                metal_type=form.metal_type.data,
                investment_amount=investment_amount,
                currency=form.currency.data,
                price_per_gram=price_per_gram,
                quantity_grams=quantity_grams
            )
            
            db.session.add(investment)
            db.session.commit()
            
            flash(f'Investment of {investment_amount} {form.currency.data} in {form.metal_type.data} added successfully!', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            logging.error(f"Error adding investment: {e}")
            db.session.rollback()
            flash('Error adding investment. Please try again.', 'error')
    
    return render_template('add_investment.html', form=form)


@app.route('/update_prices', methods=['GET', 'POST'])
def update_prices():
    """Update current metal prices"""
    form = PriceUpdateForm()
    
    # Get current prices for form defaults
    current_prices = get_current_prices()
    if current_prices['gold']:
        form.gold_price_aed.data = current_prices['gold'].price_aed
    if current_prices['silver']:
        form.silver_price_aed.data = current_prices['silver'].price_aed
    
    if form.validate_on_submit():
        try:
            # Update or create gold price
            gold_price = MetalPrice.query.filter_by(metal_type='gold').first()
            if gold_price:
                gold_price.price_aed = form.gold_price_aed.data
            else:
                gold_price = MetalPrice(metal_type='gold', price_aed=form.gold_price_aed.data)
                db.session.add(gold_price)
            
            # Update or create silver price
            silver_price = MetalPrice.query.filter_by(metal_type='silver').first()
            if silver_price:
                silver_price.price_aed = form.silver_price_aed.data
            else:
                silver_price = MetalPrice(metal_type='silver', price_aed=form.silver_price_aed.data)
                db.session.add(silver_price)
            
            db.session.commit()
            flash('Metal prices updated successfully!', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            logging.error(f"Error updating prices: {e}")
            db.session.rollback()
            flash('Error updating prices. Please try again.', 'error')
    
    return render_template('update_prices.html', form=form, current_prices=current_prices)


@app.route('/profit_calculator', methods=['GET', 'POST'])
def profit_calculator():
    """Calculate profit scenarios"""
    form = ProfitCalculatorForm()
    custom_form = CustomPriceForm()
    scenarios = []
    custom_results = None
    
    if form.validate_on_submit() and form.submit.data:
        try:
            # Save scenario for future reference
            scenario = ProfitScenario(
                name=form.scenario_name.data,
                percentage_growth=form.percentage_growth.data
            )
            db.session.add(scenario)
            db.session.commit()
            
            # Calculate profit scenarios
            scenarios = calculate_profit_scenarios([form.percentage_growth.data])
            flash(f'Profit scenario "{form.scenario_name.data}" calculated successfully!', 'success')
            
        except Exception as e:
            logging.error(f"Error calculating profit scenario: {e}")
            db.session.rollback()
            flash('Error calculating profit scenario. Please try again.', 'error')
    
    elif custom_form.validate_on_submit() and custom_form.submit.data:
        try:
            # Calculate with custom future prices
            custom_results = calculate_profit_scenarios(
                percentages=[],
                custom_gold_price=custom_form.gold_future_price.data,
                custom_silver_price=custom_form.silver_future_price.data
            )
            flash('Custom price profit calculation completed!', 'success')
            
        except Exception as e:
            logging.error(f"Error calculating custom profit: {e}")
            flash('Error calculating custom profit. Please try again.', 'error')
    
    # Get saved scenarios
    saved_scenarios = ProfitScenario.query.order_by(ProfitScenario.created_at.desc()).limit(5).all()
    
    return render_template('profit_calculator.html', 
                         form=form, 
                         custom_form=custom_form,
                         scenarios=scenarios,
                         custom_results=custom_results,
                         saved_scenarios=saved_scenarios)


@app.route('/reports')
def reports():
    """View and generate reports"""
    try:
        # Get all investments grouped by metal type
        investments = Investment.query.order_by(Investment.date.desc()).all()
        
        # Calculate summary statistics
        summary = {
            'total_investments': len(investments),
            'gold_total_amount': sum(inv.investment_amount for inv in investments if inv.metal_type == 'gold'),
            'silver_total_amount': sum(inv.investment_amount for inv in investments if inv.metal_type == 'silver'),
            'gold_total_quantity': sum(inv.quantity_grams for inv in investments if inv.metal_type == 'gold'),
            'silver_total_quantity': sum(inv.quantity_grams for inv in investments if inv.metal_type == 'silver'),
        }
        
        return render_template('reports.html', investments=investments, summary=summary)
        
    except Exception as e:
        logging.error(f"Error loading reports: {e}")
        flash('Error loading reports data', 'error')
        return render_template('reports.html', investments=[], summary={})


@app.route('/generate_pdf')
def generate_pdf():
    """Generate and download PDF report"""
    try:
        pdf_content = generate_pdf_report()
        
        response = make_response(pdf_content)
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = 'attachment; filename=investment_report.pdf'
        
        return response
        
    except Exception as e:
        logging.error(f"Error generating PDF: {e}")
        flash('Error generating PDF report. Please try again.', 'error')
        return redirect(url_for('reports'))


@app.errorhandler(404)
def not_found_error(error):
    return render_template('base.html'), 404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('base.html'), 500
