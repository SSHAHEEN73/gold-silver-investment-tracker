from app import db
from models import Investment, MetalPrice, ProfitScenario
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from io import BytesIO
from datetime import datetime
import logging


def get_current_prices():
    """Get current metal prices"""
    gold_price = MetalPrice.query.filter_by(metal_type='gold').first()
    silver_price = MetalPrice.query.filter_by(metal_type='silver').first()

    return {'gold': gold_price, 'silver': silver_price}


def calculate_profit_scenarios(percentages,
                               custom_gold_price=None,
                               custom_silver_price=None):
    """Calculate profit scenarios based on percentage growth or custom prices"""
    try:
        # Get all investments
        investments = Investment.query.all()
        current_prices = get_current_prices()

        if not current_prices['gold'] or not current_prices['silver']:
            return []

        results = []

        if custom_gold_price is not None and custom_silver_price is not None:
            # Use custom prices
            scenarios = [{
                'name': 'Custom Prices',
                'gold_price': custom_gold_price,
                'silver_price': custom_silver_price
            }]
        else:
            # Use percentage growth
            scenarios = []
            for percentage in percentages:
                scenarios.append({
                    'name':
                    f'{percentage}% Growth',
                    'gold_price':
                    current_prices['gold'].price_aed * (1 + percentage / 100),
                    'silver_price':
                    current_prices['silver'].price_aed * (1 + percentage / 100)
                })

        for scenario in scenarios:
            gold_profit = 0
            silver_profit = 0
            gold_investment = 0
            silver_investment = 0
            gold_current_value = 0
            silver_current_value = 0

            for investment in investments:
                # Convert investment amount to AED for calculations
                if investment.currency == 'KWD':
                    investment_aed = investment.investment_amount * 12
                else:
                    investment_aed = investment.investment_amount

                if investment.metal_type == 'gold':
                    gold_investment += investment_aed
                    current_value = investment.quantity_grams * scenario[
                        'gold_price']
                    gold_current_value += current_value
                    gold_profit += (current_value - investment_aed)
                else:  # silver
                    silver_investment += investment_aed
                    current_value = investment.quantity_grams * scenario[
                        'silver_price']
                    silver_current_value += current_value
                    silver_profit += (current_value - investment_aed)

            total_investment = gold_investment + silver_investment
            total_current_value = gold_current_value + silver_current_value
            total_profit = gold_profit + silver_profit
            total_profit_percentage = (total_profit / total_investment *
                                       100) if total_investment > 0 else 0

            results.append({
                'scenario_name': scenario['name'],
                'gold_price': scenario['gold_price'],
                'silver_price': scenario['silver_price'],
                'gold_investment': gold_investment,
                'silver_investment': silver_investment,
                'gold_current_value': gold_current_value,
                'silver_current_value': silver_current_value,
                'gold_profit': gold_profit,
                'silver_profit': silver_profit,
                'total_investment': total_investment,
                'total_current_value': total_current_value,
                'total_profit': total_profit,
                'total_profit_percentage': total_profit_percentage
            })

        return results

    except Exception as e:
        logging.error(f"Error calculating profit scenarios: {e}")
        return []


def generate_pdf_report():
    """Generate comprehensive PDF report"""
    try:
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4)

        # Get styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            spaceAfter=30,
            textColor=colors.darkblue,
            alignment=1  # Center alignment
        )

        story = []

        # Title
        title = Paragraph("Gold & Silver Investment Report", title_style)
        story.append(title)
        story.append(Spacer(1, 20))

        # Report date
        date_para = Paragraph(
            f"Generated on: {datetime.now().strftime('%B %d, %Y')}",
            styles['Normal'])
        story.append(date_para)
        story.append(Spacer(1, 20))

        # Summary section
        investments = Investment.query.all()
        current_prices = get_current_prices()

        # Calculate totals
        gold_total_investment = sum(
            inv.investment_amount * (12 if inv.currency == 'KWD' else 1)
            for inv in investments if inv.metal_type == 'gold')
        silver_total_investment = sum(
            inv.investment_amount * (12 if inv.currency == 'KWD' else 1)
            for inv in investments if inv.metal_type == 'silver')
        gold_total_quantity = sum(inv.quantity_grams for inv in investments
                                  if inv.metal_type == 'gold')
        silver_total_quantity = sum(inv.quantity_grams for inv in investments
                                    if inv.metal_type == 'silver')

        # Summary table
        summary_data = [
            ['Investment Summary', 'Gold', 'Silver', 'Total'],
            [
                'Total Investment (AED)', f'{gold_total_investment:.2f}',
                f'{silver_total_investment:.2f}',
                f'{gold_total_investment + silver_total_investment:.2f}'
            ],
            [
                'Total Quantity (grams)', f'{gold_total_quantity:.3f}',
                f'{silver_total_quantity:.3f}',
                f'{gold_total_quantity + silver_total_quantity:.3f}'
            ],
        ]

        if current_prices['gold'] and current_prices['silver']:
            gold_current_value = gold_total_quantity * current_prices[
                'gold'].price_aed
            silver_current_value = silver_total_quantity * current_prices[
                'silver'].price_aed
            total_current_value = gold_current_value + silver_current_value
            total_investment = gold_total_investment + silver_total_investment
            total_profit = total_current_value - total_investment

            summary_data.extend([
                [
                    'Current Value (AED)', f'{gold_current_value:.2f}',
                    f'{silver_current_value:.2f}', f'{total_current_value:.2f}'
                ],
                [
                    'Profit/Loss (AED)',
                    f'{gold_current_value - gold_total_investment:.2f}',
                    f'{silver_current_value - silver_total_investment:.2f}',
                    f'{total_profit:.2f}'
                ],
                [
                    'Return %',
                    f'{((gold_current_value - gold_total_investment) / gold_total_investment * 100):.2f}%'
                    if gold_total_investment > 0 else '0%',
                    f'{((silver_current_value - silver_total_investment) / silver_total_investment * 100):.2f}%'
                    if silver_total_investment > 0 else '0%',
                    f'{(total_profit / total_investment * 100):.2f}%'
                    if total_investment > 0 else '0%'
                ]
            ])

        summary_table = Table(summary_data)
        summary_table.setStyle(
            TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
                        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, 0), 12),
                        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black)]))

        story.append(summary_table)
        story.append(Spacer(1, 30))

        # Current prices section
        if current_prices['gold'] and current_prices['silver']:
            prices_title = Paragraph("Current Market Prices",
                                     styles['Heading2'])
            story.append(prices_title)
            story.append(Spacer(1, 10))

            prices_data = [[
                'Metal', 'Price (AED/gram)', 'Price (KWD/gram)', 'Last Updated'
            ],
                           [
                               'Gold',
                               f'{current_prices["gold"].price_aed:.2f}',
                               f'{current_prices["gold"].price_kwd:.3f}',
                               current_prices["gold"].last_updated.strftime(
                                   '%Y-%m-%d %H:%M')
                           ],
                           [
                               'Silver',
                               f'{current_prices["silver"].price_aed:.2f}',
                               f'{current_prices["silver"].price_kwd:.3f}',
                               current_prices["silver"].last_updated.strftime(
                                   '%Y-%m-%d %H:%M')
                           ]]

            prices_table = Table(prices_data)
            prices_table.setStyle(
                TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkgreen),
                            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                            ('GRID', (0, 0), (-1, -1), 1, colors.black),
                            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgreen)
                            ]))

            story.append(prices_table)
            story.append(Spacer(1, 30))

        # Investment history
        history_title = Paragraph("Investment History", styles['Heading2'])
        story.append(history_title)
        story.append(Spacer(1, 10))

        if investments:
            history_data = [[
                'Date', 'Metal', 'Amount', 'Currency', 'Price/gram',
                'Quantity (g)'
            ]]

            for inv in sorted(investments, key=lambda x: x.date, reverse=True):
                history_data.append([
                    inv.date.strftime('%Y-%m-%d'),
                    inv.metal_type.title(), f'{inv.investment_amount:.2f}',
                    inv.currency, f'{inv.price_per_gram:.2f}',
                    f'{inv.quantity_grams:.3f}'
                ])

            history_table = Table(history_data)
            history_table.setStyle(
                TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkorange),
                            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                            ('GRID', (0, 0), (-1, -1), 1, colors.black),
                            ('BACKGROUND', (0, 1), (-1, -1),
                             colors.lightyellow)]))

            story.append(history_table)
        else:
            no_data = Paragraph("No investments recorded yet.",
                                styles['Normal'])
            story.append(no_data)

        # Build PDF
        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()

    except Exception as e:
        logging.error(f"Error generating PDF report: {e}")
        raise e
